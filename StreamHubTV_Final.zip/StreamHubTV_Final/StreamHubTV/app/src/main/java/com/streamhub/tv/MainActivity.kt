package com.streamhub.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.Coil
import coil.ImageLoader
import com.streamhub.tv.network.NetworkModule
import com.streamhub.tv.ui.MainScreen
import com.streamhub.tv.ui.StreamHubViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Coil.setImageLoader(
            ImageLoader.Builder(this)
                .okHttpClient(NetworkModule.okHttpClient)
                .build()
        )
        setContent {
            val vm: StreamHubViewModel = viewModel()
            MainScreen(vm)
        }
    }
}
