package com.streamhub.tv.model

enum class OttPlatform(
    val displayName: String,
    val packageName: String,
    val mobilePackageName: String,
    val tmdbProviderQuery: String? = null,
    val fallbackWebUrl: String
) {
    JIO_HOTSTAR("JioHotstar", "in.startv.hotstar", "in.startv.hotstar", "122|2336", "https://www.hotstar.com"),
    PRIME_VIDEO("Prime Video", "com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient", "119", "https://www.primevideo.com"),
    ZEE5("ZEE5", "com.graymatrix.did", "com.graymatrix.did", "232", "https://www.zee5.com"),
    SONY_LIV("SonyLIV", "com.sonyliv", "com.sonyliv", "237", "https://www.sonyliv.com"),
    YOUTUBE("YouTube", "com.google.android.youtube.tv", "com.google.android.youtube", null, "https://www.youtube.com"),
    JIO_TV("JioTV", "com.jio.jioplay.tv", "com.jio.media.jiotv", null, "https://jiotv.com")
}

enum class AppYearFilter(val label: String, val yearParam: Int?) {
    ALL("All Years", null),
    Y2026("2026", 2026),
    Y2025("2025", 2025),
    Y2024("2024", 2024),
    Y2023("2023", 2023),
    Y2022("2022", 2022),
    Y2020("2020", 2020)
}

enum class AppLanguage(
    val label: String,
    val isoCode: String?,
    val tmdbLocale: String
) {
    ALL("All Languages", null, "en-IN"),
    HINDI("Hindi", "hi", "hi-IN"),
    GUJARATI("Gujarati", "gu", "gu-IN"),
    ENGLISH("English", "en", "en-US"),
    TAMIL("Tamil", "ta", "ta-IN"),
    TELUGU("Telugu", "te", "te-IN"),
    MARATHI("Marathi", "mr", "mr-IN")
}

enum class ContentTypeFilter(val label: String) {
    ALL("All"),
    MOVIES("Movies"),
    WEB_SERIES("Web Series"),
    SHORT_SERIES("Short Series")
}

enum class ThemeMode(val label: String) {
    DYNAMIC("Dynamic (Matches Card)"),
    MIDNIGHT("Midnight Blue"),
    AMOLED("AMOLED Black")
}

data class CastMember(
    val id: Int,
    val name: String,
    val character: String,
    val photoUrl: String
)

data class UserProfile(
    val email: String,
    val name: String
)

data class MediaItem(
    val id: String,
    val title: String,
    val overview: String,
    val imageUrl: String,
    val rating: Double,
    val releaseDate: String,
    val platform: OttPlatform,
    val deepLinkUrl: String,
    val genreIds: List<Int> = emptyList(),
    val contentTypeLabel: String = "Movie",
    val tmdbId: Int? = null,
    val isTv: Boolean = false
)

object LiveChannelCatalog {
    val channels = listOf(
        MediaItem("live_aajtak", "Aaj Tak Live", "24x7 Hindi News Live", "", 0.0, "LIVE", OttPlatform.JIO_TV, "https://www.youtube.com/results?search_query=Aaj+Tak+Live", emptyList(), "Live TV"),
        MediaItem("live_abp", "ABP News Live", "24x7 Hindi News Live", "", 0.0, "LIVE", OttPlatform.JIO_TV, "https://www.youtube.com/results?search_query=ABP+News+Live", emptyList(), "Live TV"),
        MediaItem("live_tv9guj", "TV9 Gujarati Live", "24x7 Gujarati News Live", "", 0.0, "LIVE", OttPlatform.JIO_TV, "https://www.youtube.com/results?search_query=TV9+Gujarati+Live", emptyList(), "Live TV"),
        MediaItem("live_zeenews", "Zee News Live", "Live News & Shows", "", 0.0, "LIVE", OttPlatform.ZEE5, "https://www.youtube.com/results?search_query=Zee+News+Live", emptyList(), "Live TV"),
        MediaItem("live_sonysab", "Sony SAB", "Comedy & Family Shows", "", 0.0, "LIVE", OttPlatform.SONY_LIV, "https://www.youtube.com/results?search_query=Sony+SAB+Live", emptyList(), "Live TV"),
        MediaItem("live_star", "Star Plus / Sports", "Drama & Live Cricket", "", 0.0, "LIVE", OttPlatform.JIO_HOTSTAR, "https://www.youtube.com/results?search_query=Star+Sports+Live", emptyList(), "Live TV"),
        MediaItem("live_ddsports", "DD Sports Live", "Free Live Sports", "", 0.0, "LIVE", OttPlatform.JIO_TV, "https://www.youtube.com/results?search_query=DD+Sports+Live", emptyList(), "Live TV")
    )
}

object GenreCatalog {
    val genres = listOf(
        28 to "Action",
        35 to "Comedy",
        18 to "Drama",
        53 to "Thriller",
        80 to "Crime",
        10749 to "Romance",
        878 to "Sci-Fi",
        10751 to "Family",
        27 to "Horror",
        16 to "Animation",
        99 to "Documentary"
    )
}
