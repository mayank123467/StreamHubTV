package com.streamhub.tv.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streamhub.tv.data.ContentRepository
import com.streamhub.tv.model.*
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HubUiState(
    val isLoading: Boolean = true,
    val hasApiKeys: Boolean = false,
    val selectedPlatform: OttPlatform? = null,
    val selectedLanguage: AppLanguage = AppLanguage.ALL,
    val selectedCategory: ContentTypeFilter = ContentTypeFilter.ALL,
    val heroTop10: List<MediaItem> = emptyList(),
    val activeHeroIndex: Int = 0,
    val latestMovies: List<MediaItem> = emptyList(),
    val webSeries: List<MediaItem> = emptyList(),
    val shortSeries: List<MediaItem> = emptyList(),
    val mostRated: List<MediaItem> = emptyList(),
    val forYou: List<MediaItem> = emptyList(),
    val youtubeTrending: List<MediaItem> = emptyList(),
    val selectedGenres: Set<Int> = emptySet(),
    val selectedItem: MediaItem? = null,
    val showInterestPicker: Boolean = false,
    val showSearch: Boolean = false,
    val searchQuery: String = "",
    val searchResults: List<MediaItem> = emptyList(),
    val isSearching: Boolean = false,
    val showMenu: Boolean = false,
    val showSettings: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.DYNAMIC,
    val autoSlideHero: Boolean = true
)

class StreamHubViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ContentRepository(app)
    private val _state = MutableStateFlow(
        HubUiState(
            selectedGenres = repo.getSelectedGenres(),
            hasApiKeys = repo.hasApiKeys(),
            themeMode = repo.getThemeMode(),
            autoSlideHero = repo.getAutoSlideHero()
        )
    )
    val state: StateFlow<HubUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun selectPlatform(platform: OttPlatform?) {
        val next = if (_state.value.selectedPlatform == platform) null else platform
        _state.value = _state.value.copy(selectedPlatform = next, activeHeroIndex = 0)
        refresh()
    }

    fun selectLanguage(language: AppLanguage) {
        _state.value = _state.value.copy(selectedLanguage = language, activeHeroIndex = 0)
        refresh()
    }

    fun selectCategory(category: ContentTypeFilter) {
        _state.value = _state.value.copy(selectedCategory = category)
    }

    fun setHeroIndex(index: Int) {
        val size = _state.value.heroTop10.size
        if (size > 0) {
            _state.value = _state.value.copy(activeHeroIndex = ((index % size) + size) % size)
        }
    }

    fun refresh() {
        val currentPlatform = _state.value.selectedPlatform
        val currentLang = _state.value.selectedLanguage
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true)
            val moviesDeferred = async { repo.fetchLatestMovies(currentPlatform, currentLang) }
            val seriesDeferred = async { repo.fetchWebSeries(currentPlatform, currentLang) }
            val shortsDeferred = async { repo.fetchShortSeries(currentPlatform, currentLang) }
            val ratedDeferred = async { repo.fetchMostRatedOtt(currentPlatform, currentLang) }
            val ytDeferred = async {
                if (currentPlatform == null || currentPlatform == OttPlatform.YOUTUBE) {
                    repo.fetchYouTubeTrending(currentLang)
                } else emptyList()
            }

            val movies = moviesDeferred.await()
            val series = seriesDeferred.await()
            val shorts = shortsDeferred.await()
            val rated = ratedDeferred.await()
            val yt = ytDeferred.await()
            val genres = _state.value.selectedGenres

            val combined = (movies + series + shorts + rated).distinctBy { it.id }
            val interested = combined
                .sortedByDescending { item -> item.genreIds.count { it in genres } * 10 + item.rating }
                .take(15)

            val top10Mix = buildList {
                addAll(movies.take(4))
                addAll(series.take(3))
                addAll(shorts.take(3))
                if (isEmpty()) addAll(yt.take(10))
            }.distinctBy { it.id }.take(10)

            _state.value = _state.value.copy(
                isLoading = false,
                heroTop10 = top10Mix,
                activeHeroIndex = 0,
                latestMovies = movies,
                webSeries = series,
                shortSeries = shorts,
                mostRated = rated,
                forYou = interested,
                youtubeTrending = yt
            )
        }
    }

    fun toggleGenre(genreId: Int) {
        val updated = repo.toggleGenre(genreId)
        val combined = (_state.value.latestMovies + _state.value.webSeries + _state.value.mostRated).distinctBy { it.id }
        val interested = combined
            .sortedByDescending { item -> item.genreIds.count { it in updated } * 10 + item.rating }
            .take(15)
        _state.value = _state.value.copy(selectedGenres = updated, forYou = interested)
    }

    fun resetGenres() {
        val defaults = repo.clearGenres()
        _state.value = _state.value.copy(selectedGenres = defaults)
        refresh()
    }

    fun setThemeMode(mode: ThemeMode) {
        repo.setThemeMode(mode)
        _state.value = _state.value.copy(themeMode = mode)
    }

    fun setAutoSlideHero(enabled: Boolean) {
        repo.setAutoSlideHero(enabled)
        _state.value = _state.value.copy(autoSlideHero = enabled)
    }

    fun toggleSearch(show: Boolean) {
        _state.value = _state.value.copy(showSearch = show, showMenu = false)
    }

    fun updateSearchQuery(query: String) {
        _state.value = _state.value.copy(searchQuery = query)
    }

    fun executeSearch() {
        val q = _state.value.searchQuery.trim()
        if (q.isBlank()) return
        viewModelScope.launch {
            _state.value = _state.value.copy(isSearching = true)
            val results = repo.searchAll(q, _state.value.selectedLanguage)
            _state.value = _state.value.copy(isSearching = false, searchResults = results)
        }
    }

    fun selectItem(item: MediaItem?) {
        _state.value = _state.value.copy(selectedItem = item)
    }

    fun toggleInterestPicker(show: Boolean) {
        _state.value = _state.value.copy(showInterestPicker = show, showMenu = false)
    }

    fun toggleMenu(show: Boolean) {
        _state.value = _state.value.copy(showMenu = show)
    }

    fun toggleSettings(show: Boolean) {
        _state.value = _state.value.copy(showSettings = show, showMenu = false)
    }
}
