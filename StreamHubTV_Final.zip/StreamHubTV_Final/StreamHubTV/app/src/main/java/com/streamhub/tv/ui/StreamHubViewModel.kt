package com.streamhub.tv.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streamhub.tv.data.ContentRepository
import com.streamhub.tv.data.FreeStreamResult
import com.streamhub.tv.model.*
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HubUiState(
    val isLoading: Boolean = true,
    val hasApiKeys: Boolean = false,
    val selectedPlatform: OttPlatform? = null,
    val selectedLanguage: AppLanguage = AppLanguage.ALL,
    val selectedCategory: ContentTypeFilter = ContentTypeFilter.ALL,
    val heroTop10: List<MediaItem> = emptyList(),
    val activeHeroIndex: Int = 0,
    val heroTrailerVideoId: String? = null,
    val latestMovies: List<MediaItem> = emptyList(),
    val webSeries: List<MediaItem> = emptyList(),
    val shortSeries: List<MediaItem> = emptyList(),
    val mostRated: List<MediaItem> = emptyList(),
    val forYou: List<MediaItem> = emptyList(),
    val youtubeTrending: List<MediaItem> = emptyList(),
    val selectedGenres: Set<Int> = emptySet(),
    val detailStack: List<MediaItem> = emptyList(),
    val castList: List<CastMember> = emptyList(),
    val similarItems: List<MediaItem> = emptyList(),
    val isLoadingDetails: Boolean = false,
    val trailerVideoId: String? = null,
    val isLoadingTrailer: Boolean = false,
    val freeMp4Url: String? = null,
    val isLoadingFree: Boolean = false,
    val freeNotice: String? = null,
    val showInterestPicker: Boolean = false,
    val showSearch: Boolean = false,
    val searchQuery: String = "",
    val searchResults: List<MediaItem> = emptyList(),
    val isSearching: Boolean = false,
    val showMenu: Boolean = false,
    val showSettings: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.DYNAMIC,
    val autoSlideHero: Boolean = true
) {
    val selectedItem: MediaItem? get() = detailStack.lastOrNull()
}

class StreamHubViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ContentRepository(app)
    private val _state = MutableStateFlow(
        HubUiState(
            selectedGenres = repo.getSelectedGenres(),
            hasApiKeys = repo.hasApiKeys(),
            themeMode = repo.getThemeMode(),
            autoSlideHero = repo.getAutoSlideHero()
        )
    )
    val state: StateFlow<HubUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun selectPlatform(platform: OttPlatform?) {
        val next = if (_state.value.selectedPlatform == platform) null else platform
        _state.value = _state.value.copy(selectedPlatform = next, activeHeroIndex = 0, heroTrailerVideoId = null)
        refresh()
    }

    fun selectLanguage(language: AppLanguage) {
        _state.value = _state.value.copy(selectedLanguage = language, activeHeroIndex = 0, heroTrailerVideoId = null)
        refresh()
    }

    fun selectCategory(category: ContentTypeFilter) {
        _state.value = _state.value.copy(selectedCategory = category)
    }

    fun setHeroIndex(index: Int) {
        if (_state.value.heroTrailerVideoId != null) return
        val size = _state.value.heroTop10.size
        if (size > 0) {
            _state.value = _state.value.copy(activeHeroIndex = ((index % size) + size) % size)
        }
    }

    fun refresh() {
        val currentPlatform = _state.value.selectedPlatform
        val currentLang = _state.value.selectedLanguage
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true)
            val moviesDeferred = async { repo.fetchLatestMovies(currentPlatform, currentLang) }
            val seriesDeferred = async { repo.fetchWebSeries(currentPlatform, currentLang) }
            val shortsDeferred = async { repo.fetchShortSeries(currentPlatform, currentLang) }
            val ratedDeferred = async { repo.fetchMostRatedOtt(currentPlatform, currentLang) }
            val ytDeferred = async {
                if (currentPlatform == null || currentPlatform == OttPlatform.YOUTUBE) {
                    repo.fetchYouTubeTrending(currentLang)
                } else emptyList()
            }

            val movies = moviesDeferred.await()
            val series = seriesDeferred.await()
            val shorts = shortsDeferred.await()
            val rated = ratedDeferred.await()
            val yt = ytDeferred.await()
            val genres = _state.value.selectedGenres

            val combined = (movies + series + shorts + rated).distinctBy { it.id }
            val interested = combined
                .sortedByDescending { item -> item.genreIds.count { it in genres } * 10 + item.rating }
                .take(15)

            val top10Mix = buildList {
                addAll(movies.take(4))
                addAll(series.take(3))
                addAll(shorts.take(3))
                if (isEmpty()) addAll(yt.take(10))
            }.distinctBy { it.id }.take(10)

            _state.value = _state.value.copy(
                isLoading = false,
                heroTop10 = top10Mix,
                activeHeroIndex = 0,
                heroTrailerVideoId = null,
                latestMovies = movies,
                webSeries = series,
                shortSeries = shorts,
                mostRated = rated,
                forYou = interested,
                youtubeTrending = yt
            )
        }
    }

    fun toggleGenre(genreId: Int) {
        val updated = repo.toggleGenre(genreId)
        val combined = (_state.value.latestMovies + _state.value.webSeries + _state.value.mostRated).distinctBy { it.id }
        val interested = combined
            .sortedByDescending { item -> item.genreIds.count { it in updated } * 10 + item.rating }
            .take(15)
        _state.value = _state.value.copy(selectedGenres = updated, forYou = interested)
    }

    fun resetGenres() {
        val defaults = repo.clearGenres()
        _state.value = _state.value.copy(selectedGenres = defaults)
        refresh()
    }

    fun setThemeMode(mode: ThemeMode) {
        repo.setThemeMode(mode)
        _state.value = _state.value.copy(themeMode = mode)
    }

    fun setAutoSlideHero(enabled: Boolean) {
        repo.setAutoSlideHero(enabled)
        _state.value = _state.value.copy(autoSlideHero = enabled)
    }

    fun toggleSearch(show: Boolean) {
        _state.value = _state.value.copy(showSearch = show, showMenu = false)
    }

    fun updateSearchQuery(query: String) {
        _state.value = _state.value.copy(searchQuery = query)
    }

    fun executeSearch() {
        val q = _state.value.searchQuery.trim()
        if (q.isBlank()) return
        viewModelScope.launch {
            _state.value = _state.value.copy(isSearching = true)
            val results = repo.searchAll(q, _state.value.selectedLanguage)
            _state.value = _state.value.copy(isSearching = false, searchResults = results)
        }
    }

    fun openDetail(item: MediaItem) {
        _state.value = _state.value.copy(
            detailStack = _state.value.detailStack + item,
            castList = emptyList(),
            similarItems = emptyList(),
            isLoadingDetails = true,
            trailerVideoId = null,
            heroTrailerVideoId = null
        )
        viewModelScope.launch {
            val castDeferred = async { repo.fetchCast(item) }
            val similarDeferred = async { repo.fetchSimilar(item, _state.value.selectedLanguage) }
            val cast = castDeferred.await()
            val similar = similarDeferred.await()
            if (_state.value.selectedItem?.id == item.id) {
                _state.value = _state.value.copy(
                    castList = cast,
                    similarItems = similar,
                    isLoadingDetails = false
                )
            }
        }
    }

    fun navigateBack() {
        val stack = _state.value.detailStack
        if (stack.size <= 1) {
            goHome()
        } else {
            val prev = stack.dropLast(1)
            val top = prev.last()
            _state.value = _state.value.copy(
                detailStack = prev,
                castList = emptyList(),
                similarItems = emptyList(),
                isLoadingDetails = true,
                trailerVideoId = null
            )
            viewModelScope.launch {
                val cast = repo.fetchCast(top)
                val similar = repo.fetchSimilar(top, _state.value.selectedLanguage)
                if (_state.value.selectedItem?.id == top.id) {
                    _state.value = _state.value.copy(castList = cast, similarItems = similar, isLoadingDetails = false)
                }
            }
        }
    }

    fun goHome() {
        _state.value = _state.value.copy(
            detailStack = emptyList(),
            castList = emptyList(),
            similarItems = emptyList(),
            trailerVideoId = null,
            showSearch = false,
            showSettings = false,
            showMenu = false
        )
    }

    fun playHeroTrailer(item: MediaItem, onFallback: () -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoadingTrailer = true)
            val key = repo.fetchTrailerKey(item)
            _state.value = _state.value.copy(isLoadingTrailer = false)
            if (!key.isNullOrBlank()) {
                _state.value = _state.value.copy(heroTrailerVideoId = key)
            } else {
                onFallback()
            }
        }
    }

    fun closeHeroTrailer() {
        _state.value = _state.value.copy(heroTrailerVideoId = null)
    }

    fun playTrailer(item: MediaItem, onFallback: () -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoadingTrailer = true)
            val key = repo.fetchTrailerKey(item)
            _state.value = _state.value.copy(isLoadingTrailer = false)
            if (!key.isNullOrBlank()) {
                _state.value = _state.value.copy(trailerVideoId = key)
            } else {
                onFallback()
            }
        }
    }


    fun playFree(item: MediaItem) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoadingFree = true, freeNotice = null)
            when (val res = repo.findFreeLegalStream(item)) {
                is FreeStreamResult.DirectMp4 -> {
                    _state.value = _state.value.copy(isLoadingFree = false, freeMp4Url = res.url)
                }
                is FreeStreamResult.YouTubeVideo -> {
                    _state.value = _state.value.copy(isLoadingFree = false, trailerVideoId = res.videoId)
                }
                FreeStreamResult.NotFound -> {
                    _state.value = _state.value.copy(
                        isLoadingFree = false,
                        freeNotice = "No free legal stream found for this title. Use Watch on ${item.platform.displayName}."
                    )
                }
            }
        }
    }

    fun closeFreePlayer() {
        _state.value = _state.value.copy(freeMp4Url = null)
    }

    fun clearFreeNotice() {
        _state.value = _state.value.copy(freeNotice = null)
    }

    fun closeTrailer() {
        _state.value = _state.value.copy(trailerVideoId = null)
    }

    fun toggleInterestPicker(show: Boolean) {
        _state.value = _state.value.copy(showInterestPicker = show, showMenu = false)
    }

    fun toggleMenu(show: Boolean) {
        _state.value = _state.value.copy(showMenu = show)
    }

    fun toggleSettings(show: Boolean) {
        _state.value = _state.value.copy(showSettings = show, showMenu = false)
    }
}
