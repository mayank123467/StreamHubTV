package com.streamhub.tv.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import androidx.tv.material3.Text
import coil.compose.AsyncImage
import com.streamhub.tv.model.*
import com.streamhub.tv.util.AppLauncher
import kotlinx.coroutines.delay

private fun platformAccent(platform: OttPlatform): Color = when (platform) {
    OttPlatform.JIO_HOTSTAR -> Color(0xFF0F4C81)
    OttPlatform.PRIME_VIDEO -> Color(0xFF0078B8)
    OttPlatform.ZEE5 -> Color(0xFF7B2CBF)
    OttPlatform.SONY_LIV -> Color(0xFFEA580C)
    OttPlatform.YOUTUBE -> Color(0xFFDC2626)
    OttPlatform.JIO_TV -> Color(0xFFE11D48)
}

private fun platformBgTint(platform: OttPlatform): Color = when (platform) {
    OttPlatform.JIO_HOTSTAR -> Color(0xFF081A33)
    OttPlatform.PRIME_VIDEO -> Color(0xFF062033)
    OttPlatform.ZEE5 -> Color(0xFF1E0B36)
    OttPlatform.SONY_LIV -> Color(0xFF2B1205)
    OttPlatform.YOUTUBE -> Color(0xFF2B0909)
    OttPlatform.JIO_TV -> Color(0xFF2D0A18)
}

private fun platformShortTag(platform: OttPlatform): String = when (platform) {
    OttPlatform.JIO_HOTSTAR -> "JH"
    OttPlatform.PRIME_VIDEO -> "PV"
    OttPlatform.ZEE5 -> "Z5"
    OttPlatform.SONY_LIV -> "SL"
    OttPlatform.YOUTUBE -> "YT"
    OttPlatform.JIO_TV -> "JT"
}

private fun platformSubtitle(platform: OttPlatform): String = when (platform) {
    OttPlatform.JIO_HOTSTAR -> "Sports & Specials"
    OttPlatform.PRIME_VIDEO -> "Originals & Movies"
    OttPlatform.ZEE5 -> "Hindi & Regional"
    OttPlatform.SONY_LIV -> "Shows & Thrillers"
    OttPlatform.YOUTUBE -> "Trending & Videos"
    OttPlatform.JIO_TV -> "Live TV Channels"
}

@Composable
private fun TouchTvButton(
    text: String,
    containerColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(containerColor)
            .then(
                if (focused) Modifier.border(2.dp, Color.White, RoundedCornerShape(24.dp))
                else Modifier
            )
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun TouchTvCard(
    onClick: () -> Unit,
    selected: Boolean = false,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val showBorder = selected || focused
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .then(
                if (showBorder) Modifier.border(2.dp, Color.White, RoundedCornerShape(12.dp))
                else Modifier
            )
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick),
        content = content
    )
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun MainScreen(viewModel: StreamHubViewModel) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current

    val heroList = state.heroTop10
    val activeHero = heroList.getOrNull(state.activeHeroIndex)

    LaunchedEffect(heroList.size, state.autoSlideHero) {
        if (state.autoSlideHero && heroList.size > 1) {
            while (true) {
                delay(5000)
                viewModel.setHeroIndex(state.activeHeroIndex + 1)
            }
        }
    }

    val targetBg = when (state.themeMode) {
        ThemeMode.AMOLED -> Color(0xFF000000)
        ThemeMode.MIDNIGHT -> Color(0xFF090D16)
        ThemeMode.DYNAMIC -> {
            val activePlatform = state.selectedItem?.platform
                ?: state.selectedPlatform
                ?: activeHero?.platform
            if (activePlatform != null) platformBgTint(activePlatform) else Color(0xFF090D16)
        }
    }
    val animatedBg by animateColorAsState(targetValue = targetBg, animationSpec = tween(600))

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(animatedBg, Color(0xFF060911)))
            )
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "StreamHub TV",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${state.selectedPlatform?.displayName ?: "All OTT"} • ${state.selectedLanguage.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF60A5FA)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TouchTvButton(
                            text = "🔍 Search",
                            containerColor = Color(0xFF1E293B),
                            onClick = { viewModel.toggleSearch(true) }
                        )
                        TouchTvButton(
                            text = if (state.showInterestPicker) "Done" else "Interests",
                            containerColor = Color(0xFF2563EB),
                            onClick = { viewModel.toggleInterestPicker(!state.showInterestPicker) }
                        )
                        TouchTvButton(
                            text = "⋮",
                            containerColor = Color(0xFF1E293B),
                            onClick = { viewModel.toggleMenu(!state.showMenu) }
                        )
                    }
                }
            }

            if (state.showInterestPicker) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(GenreCatalog.genres) { (id, name) ->
                            val selected = id in state.selectedGenres
                            TouchTvButton(
                                text = if (selected) "✓ $name" else name,
                                containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                onClick = { viewModel.toggleGenre(id) }
                            )
                        }
                    }
                }
            }

            if (activeHero != null && state.selectedPlatform != OttPlatform.JIO_TV) {
                item {
                    val heroAccent = platformAccent(activeHero.platform)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(215.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF161D2E))
                    ) {
                        if (activeHero.imageUrl.isNotBlank()) {
                            AsyncImage(
                                model = activeHero.imageUrl,
                                contentDescription = activeHero.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xEE090D16), Color(0xAA090D16), Color(0x33090D16))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(20.dp)
                                .fillMaxWidth(0.76f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "TOP ${state.activeHeroIndex + 1}/${heroList.size} • ${activeHero.contentTypeLabel.uppercase()} • ${activeHero.platform.displayName.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF38BDF8),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = activeHero.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = activeHero.overview.ifBlank { "Top pick in ${state.selectedLanguage.label}" },
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFCBD5E1),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                TouchTvButton(
                                    text = "Watch Now",
                                    containerColor = heroAccent,
                                    onClick = { AppLauncher.openPlatform(context, activeHero.platform, activeHero.deepLinkUrl) }
                                )
                                TouchTvButton(
                                    text = "‹",
                                    containerColor = Color(0xAA1E293B),
                                    onClick = { viewModel.setHeroIndex(state.activeHeroIndex - 1) }
                                )
                                TouchTvButton(
                                    text = "›",
                                    containerColor = Color(0xAA1E293B),
                                    onClick = { viewModel.setHeroIndex(state.activeHeroIndex + 1) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Category", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(ContentTypeFilter.entries) { cat ->
                            val selected = state.selectedCategory == cat
                            TouchTvButton(
                                text = cat.label,
                                containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                onClick = { viewModel.selectCategory(cat) }
                            )
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Language (Original + Dubbed)", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(AppLanguage.entries) { lang ->
                            val selected = state.selectedLanguage == lang
                            TouchTvButton(
                                text = lang.label,
                                containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                onClick = { viewModel.selectLanguage(lang) }
                            )
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("OTT Apps", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        state.selectedPlatform?.let { selected ->
                            TouchTvButton(
                                text = "Open ${selected.displayName}",
                                containerColor = platformAccent(selected),
                                onClick = { AppLauncher.openPlatform(context, selected) }
                            )
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            val isAll = state.selectedPlatform == null
                            TouchTvCard(
                                onClick = { viewModel.selectPlatform(null) },
                                selected = isAll,
                                modifier = Modifier.width(105.dp).height(78.dp)
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize().background(Color(0xFF1E293B)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("All OTT", style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        items(OttPlatform.entries) { platform ->
                            val accent = platformAccent(platform)
                            val isSelected = state.selectedPlatform == platform
                            TouchTvCard(
                                onClick = { viewModel.selectPlatform(platform) },
                                selected = isSelected,
                                modifier = Modifier.width(182.dp).height(78.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.85f), Color(0xFF1E293B))))
                                        .padding(horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(platformShortTag(platform), style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text(platform.displayName, style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text(platformSubtitle(platform), style = MaterialTheme.typography.labelSmall, color = Color(0xFFE2E8F0), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (state.selectedPlatform == OttPlatform.JIO_TV) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = SurfaceDefaults.colors(containerColor = Color(0xFF161D2E))
                    ) {
                        Row(
                            modifier = Modifier.padding(20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("JioTV Live Channels", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                Text("Live TV channels stream directly inside the JioTV app.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF94A3B8))
                            }
                            TouchTvButton(
                                text = "Launch JioTV",
                                containerColor = platformAccent(OttPlatform.JIO_TV),
                                onClick = { AppLauncher.openPlatform(context, OttPlatform.JIO_TV) }
                            )
                        }
                    }
                }
            }

            val cat = state.selectedCategory
            if ((cat == ContentTypeFilter.ALL) && state.forYou.isNotEmpty()) {
                item { ContentRow("My Interested Content", state.forYou) { viewModel.selectItem(it) } }
            }
            if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.MOVIES) && state.latestMovies.isNotEmpty()) {
                item { ContentRow("Latest Movies", state.latestMovies) { viewModel.selectItem(it) } }
            }
            if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.WEB_SERIES) && state.webSeries.isNotEmpty()) {
                item { ContentRow("Top Web Series", state.webSeries) { viewModel.selectItem(it) } }
            }
            if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.SHORT_SERIES) && state.shortSeries.isNotEmpty()) {
                item { ContentRow("Short Series & Mini Shows", state.shortSeries) { viewModel.selectItem(it) } }
            }
            if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.MOVIES) && state.mostRated.isNotEmpty()) {
                item { ContentRow("Most Rated", state.mostRated) { viewModel.selectItem(it) } }
            }
            if (cat == ContentTypeFilter.ALL && state.youtubeTrending.isNotEmpty()) {
                item { ContentRow("Trending on YouTube", state.youtubeTrending) { viewModel.selectItem(it) } }
            }
        }

        if (state.showMenu) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x88000000))
                    .clickable { viewModel.toggleMenu(false) },
                contentAlignment = Alignment.TopEnd
            ) {
                Column(
                    modifier = Modifier
                        .padding(top = 64.dp, end = 20.dp)
                        .width(220.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF161D2E))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TouchTvButton("↻ Refresh Catalog", Color(0xFF1E293B), {
                        viewModel.toggleMenu(false)
                        viewModel.refresh()
                    }, Modifier.fillMaxWidth())
                    TouchTvButton("⚙ Interactive Settings", Color(0xFF1E293B), { viewModel.toggleSettings(true) }, Modifier.fillMaxWidth())
                    TouchTvButton("★ Edit My Interests", Color(0xFF1E293B), { viewModel.toggleInterestPicker(true) }, Modifier.fillMaxWidth())
                    TouchTvButton("Close Menu", Color(0xFF334155), { viewModel.toggleMenu(false) }, Modifier.fillMaxWidth())
                }
            }
        }

        if (state.showSettings) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000))
                    .clickable { viewModel.toggleSettings(false) },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .width(460.dp)
                        .padding(20.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF161D2E))
                        .clickable { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Interactive Settings", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("App Theme", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            val active = state.themeMode == mode
                            TouchTvButton(
                                text = if (active) "✓ ${mode.label}" else mode.label,
                                containerColor = if (active) Color(0xFF2563EB) else Color(0xFF1E293B),
                                onClick = { viewModel.setThemeMode(mode) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    TouchTvButton(
                        text = if (state.autoSlideHero) "Top 10 Auto-Slide: ON" else "Top 10 Auto-Slide: OFF",
                        containerColor = if (state.autoSlideHero) Color(0xFF0F766E) else Color(0xFF334155),
                        onClick = { viewModel.setAutoSlideHero(!state.autoSlideHero) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TouchTvButton(
                        text = "Reset Saved Interests",
                        containerColor = Color(0xFF7F1D1D),
                        onClick = { viewModel.resetGenres() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TouchTvButton(
                        text = "Close Settings",
                        containerColor = Color(0xFF334155),
                        onClick = { viewModel.toggleSettings(false) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (state.showSearch) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xE6060911))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            if (state.searchQuery.isEmpty()) {
                                Text("Search movies, web series, YouTube...", color = Color(0xFF94A3B8), style = MaterialTheme.typography.bodyMedium)
                            }
                            BasicTextField(
                                value = state.searchQuery,
                                onValueChange = { viewModel.updateSearchQuery(it) },
                                singleLine = true,
                                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                                cursorBrush = SolidColor(Color(0xFF38BDF8)),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        TouchTvButton("Search", Color(0xFF2563EB), { viewModel.executeSearch() })
                        TouchTvButton("Close", Color(0xFF334155), { viewModel.toggleSearch(false) })
                    }

                    if (state.isSearching) {
                        Text("Searching...", color = Color(0xFF60A5FA))
                    } else if (state.searchResults.isNotEmpty()) {
                        ContentRow("Search Results (${state.searchResults.size})", state.searchResults) {
                            viewModel.selectItem(it)
                        }
                    } else if (state.searchQuery.isNotBlank()) {
                        Text("Tap Search to find titles across OTT & YouTube.", color = Color(0xFF94A3B8))
                    }
                }
            }
        }

        state.selectedItem?.let { item ->
            val accent = platformAccent(item.platform)
            val ratingText = if (item.rating > 0) String.format("%.1f", item.rating) else "Trending"
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000))
                    .clickable { viewModel.selectItem(null) },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.width(520.dp).padding(20.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = SurfaceDefaults.colors(containerColor = Color(0xFF161D2E))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(item.title, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text(
                            text = "${item.contentTypeLabel}  •  ${item.platform.displayName}  •  ★ $ratingText  •  ${item.releaseDate}",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFF60A5FA)
                        )
                        Text(
                            text = item.overview.ifBlank { "Open in ${item.platform.displayName} on your device." },
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD1D5DB),
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            TouchTvButton(
                                text = "Watch on ${item.platform.displayName}",
                                containerColor = accent,
                                onClick = { AppLauncher.openPlatform(context, item.platform, item.deepLinkUrl) }
                            )
                            TouchTvButton(
                                text = "Close",
                                containerColor = Color(0xFF334155),
                                onClick = { viewModel.selectItem(null) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContentRow(
    title: String,
    items: List<MediaItem>,
    onSelect: (MediaItem) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Color.White)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items, key = { it.id }) { item ->
                val accent = platformAccent(item.platform)
                val cardRating = String.format("%.1f", item.rating)
                TouchTvCard(
                    onClick = { onSelect(item) },
                    modifier = Modifier.width(172.dp).height(250.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF161D2E))) {
                        Box(modifier = Modifier.fillMaxWidth().height(172.dp)) {
                            if (item.imageUrl.isNotBlank()) {
                                AsyncImage(
                                    model = item.imageUrl,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.8f), Color(0xFF1E293B)))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(platformShortTag(item.platform), style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (item.rating > 0) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xCC0F172A))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("★ $cardRating", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFACC15))
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(accent)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(item.platform.displayName, style = MaterialTheme.typography.labelSmall, color = Color.White)
                            }
                        }

                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
