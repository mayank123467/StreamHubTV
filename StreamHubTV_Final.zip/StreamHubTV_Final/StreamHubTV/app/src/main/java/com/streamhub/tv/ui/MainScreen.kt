package com.streamhub.tv.ui

import android.annotation.SuppressLint
import android.app.Activity
import androidx.activity.compose.BackHandler
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import androidx.tv.material3.Text
import coil.compose.AsyncImage
import com.streamhub.tv.model.*
import com.streamhub.tv.util.AppLauncher
import kotlinx.coroutines.delay

private fun platformAccent(platform: OttPlatform): Color = when (platform) {
    OttPlatform.JIO_HOTSTAR -> Color(0xFF0F4C81)
    OttPlatform.PRIME_VIDEO -> Color(0xFF0078B8)
    OttPlatform.ZEE5 -> Color(0xFF7B2CBF)
    OttPlatform.SONY_LIV -> Color(0xFFEA580C)
    OttPlatform.YOUTUBE -> Color(0xFFDC2626)
    OttPlatform.JIO_TV -> Color(0xFFE11D48)
}

private fun platformBgTint(platform: OttPlatform): Color = when (platform) {
    OttPlatform.JIO_HOTSTAR -> Color(0xFF081A33)
    OttPlatform.PRIME_VIDEO -> Color(0xFF062033)
    OttPlatform.ZEE5 -> Color(0xFF1E0B36)
    OttPlatform.SONY_LIV -> Color(0xFF2B1205)
    OttPlatform.YOUTUBE -> Color(0xFF2B0909)
    OttPlatform.JIO_TV -> Color(0xFF2D0A18)
}

private fun platformShortTag(platform: OttPlatform): String = when (platform) {
    OttPlatform.JIO_HOTSTAR -> "JH"
    OttPlatform.PRIME_VIDEO -> "PV"
    OttPlatform.ZEE5 -> "Z5"
    OttPlatform.SONY_LIV -> "SL"
    OttPlatform.YOUTUBE -> "YT"
    OttPlatform.JIO_TV -> "JT"
}

private fun platformSubtitle(platform: OttPlatform): String = when (platform) {
    OttPlatform.JIO_HOTSTAR -> "Sports & Specials"
    OttPlatform.PRIME_VIDEO -> "Originals & Movies"
    OttPlatform.ZEE5 -> "Hindi & Regional"
    OttPlatform.SONY_LIV -> "Shows & Thrillers"
    OttPlatform.YOUTUBE -> "Trending & Videos"
    OttPlatform.JIO_TV -> "Live TV Channels"
}

@Composable
private fun TouchTvButton(
    text: String,
    containerColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(containerColor)
            .then(
                if (focused) Modifier.border(2.dp, Color.White, RoundedCornerShape(24.dp))
                else Modifier
            )
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun TouchTvCard(
    onClick: () -> Unit,
    selected: Boolean = false,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val showBorder = selected || focused
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .then(
                if (showBorder) Modifier.border(2.dp, Color.White, RoundedCornerShape(12.dp))
                else Modifier
            )
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick),
        content = content
    )
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun MainScreen(viewModel: StreamHubViewModel) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val activity = context as? Activity

    BackHandler {
        when {
            state.showExitDialog -> viewModel.setExitDialog(false)
            state.showSearch -> viewModel.toggleSearch(false)
            state.showSettings -> viewModel.toggleSettings(false)
            state.showMenu -> viewModel.toggleMenu(false)
            state.isPlayerFullscreen -> viewModel.togglePlayerFullscreen()
            state.trailerVideoId != null || state.freeMp4Url != null -> {
                viewModel.closeTrailer()
                viewModel.closeFreePlayer()
            }
            state.heroTrailerVideoId != null -> viewModel.closeHeroTrailer()
            state.selectedItem != null -> viewModel.navigateBack()
            else -> viewModel.setExitDialog(true)
        }
    }

    val heroList = state.heroTop10
    val activeHero = heroList.getOrNull(state.activeHeroIndex)

    LaunchedEffect(heroList.size, state.autoSlideHero, state.selectedItem, state.heroTrailerVideoId) {
        if (state.autoSlideHero && heroList.size > 1 && state.selectedItem == null && state.heroTrailerVideoId == null) {
            while (true) {
                delay(5000)
                viewModel.setHeroIndex(state.activeHeroIndex + 1)
            }
        }
    }

    val targetBg = when (state.themeMode) {
        ThemeMode.AMOLED -> Color(0xFF000000)
        ThemeMode.MIDNIGHT -> Color(0xFF090D16)
        ThemeMode.DYNAMIC -> {
            val activePlatform = state.selectedItem?.platform
                ?: state.selectedPlatform
                ?: activeHero?.platform
            if (activePlatform != null) platformBgTint(activePlatform) else Color(0xFF090D16)
        }
    }
    val animatedBg by animateColorAsState(targetValue = targetBg, animationSpec = tween(600))

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(animatedBg, Color(0xFF060911)))
            )
    ) {
        val currentDetail = state.selectedItem
        if (currentDetail != null) {
            DetailScreen(
                item = currentDetail,
                cast = state.castList,
                similar = state.similarItems,
                isLoadingDetails = state.isLoadingDetails,
                isLoadingTrailer = state.isLoadingTrailer,
                hasFreeStream = state.detailFreeStream != null,
                inWatchlist = state.watchlist.any { it.id == currentDetail.id },
                onToggleWatchlist = { viewModel.toggleWatchlist(currentDetail) },
                inlineTrailerId = state.trailerVideoId,
                inlineMp4Url = state.freeMp4Url,
                isFullscreen = state.isPlayerFullscreen,
                onToggleFullscreen = { viewModel.togglePlayerFullscreen() },
                onCloseInlinePlayer = {
                    viewModel.closeTrailer()
                    viewModel.closeFreePlayer()
                },
                onBack = { viewModel.navigateBack() },
                onHome = { viewModel.goHome() },
                onWatch = {
                    if (currentDetail.platform in state.enabledPlatforms) {
                        AppLauncher.openPlatform(context, currentDetail.platform, currentDetail.deepLinkUrl, currentDetail.title)
                    } else {
                        viewModel.showLoginPrompt("Please open Settings (⋮) and enable/login ${currentDetail.platform.displayName} first.")
                    }
                },
                onWatchFree = { state.detailFreeStream?.let { viewModel.playFreeResult(it) } },
                onPlayTrailer = {
                    viewModel.playTrailer(currentDetail) {
                        AppLauncher.openYouTubeTrailer(context, currentDetail.title)
                    }
                },
                onSelectSimilar = { viewModel.openDetail(it) }
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "StreamHub TV",
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${state.selectedPlatform?.displayName ?: "All OTT"} • ${state.selectedLanguage.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF60A5FA)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            TouchTvButton(
                                text = "🔍 Search",
                                containerColor = Color(0xFF1E293B),
                                onClick = { viewModel.toggleSearch(true) }
                            )
                            TouchTvButton(
                                text = if (state.showInterestPicker) "Done" else "Interests",
                                containerColor = Color(0xFF2563EB),
                                onClick = { viewModel.toggleInterestPicker(!state.showInterestPicker) }
                            )
                            TouchTvButton(
                                text = "⋮",
                                containerColor = Color(0xFF1E293B),
                                onClick = { viewModel.toggleMenu(!state.showMenu) }
                            )
                        }
                    }
                }

                if (state.showInterestPicker) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(GenreCatalog.genres) { (id, name) ->
                                val selected = id in state.selectedGenres
                                TouchTvButton(
                                    text = if (selected) "✓ $name" else name,
                                    containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                    onClick = { viewModel.toggleGenre(id) }
                                )
                            }
                        }
                    }
                }

                if (activeHero != null && state.selectedPlatform != OttPlatform.JIO_TV) {
                    item {
                        val heroAccent = platformAccent(activeHero.platform)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(225.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(Color(0xFF161D2E))
                                    .clickable(enabled = state.heroTrailerVideoId == null) {
                                        viewModel.openDetail(activeHero)
                                    }
                            ) {
                                val heroTrailerId = state.heroTrailerVideoId
                                if (heroTrailerId != null) {
                                    EmbeddedYouTubePlayer(
                                        videoId = heroTrailerId,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(10.dp)
                                    ) {
                                        TouchTvButton(
                                            text = "✕ Close Trailer",
                                            containerColor = Color(0xCCDC2626),
                                            onClick = { viewModel.closeHeroTrailer() }
                                        )
                                    }
                                } else {
                                    if (activeHero.imageUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = activeHero.imageUrl,
                                            contentDescription = activeHero.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.horizontalGradient(
                                                    listOf(Color(0xEE090D16), Color(0xAA090D16), Color(0x33090D16))
                                                )
                                            )
                                    )
                                    Column(
                                        modifier = Modifier
                                            .align(Alignment.CenterStart)
                                            .padding(20.dp)
                                            .fillMaxWidth(0.82f),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "TOP ${state.activeHeroIndex + 1}/${heroList.size} • ${activeHero.contentTypeLabel.uppercase()} • ${activeHero.platform.displayName.uppercase()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF38BDF8),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = activeHero.title,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = activeHero.overview.ifBlank { "Top pick in ${state.selectedLanguage.label}" },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFFCBD5E1),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            TouchTvButton(
                                                text = "Watch Now",
                                                containerColor = heroAccent,
                                                onClick = { AppLauncher.openPlatform(context, activeHero.platform, activeHero.deepLinkUrl, activeHero.title) }
                                            )
                                            state.heroFreeStream?.let { freeRes ->
                                                TouchTvButton(
                                                    text = "▶ Watch Free",
                                                    containerColor = Color(0xFF059669),
                                                    onClick = { viewModel.playFreeResult(freeRes) }
                                                )
                                            }
                                            TouchTvButton(
                                                text = "▶ Trailer",
                                                containerColor = Color(0xFFDC2626),
                                                onClick = {
                                                    viewModel.playHeroTrailer(activeHero) {
                                                        AppLauncher.openYouTubeTrailer(context, activeHero.title)
                                                    }
                                                }
                                            )
                                            TouchTvButton(
                                                text = "‹",
                                                containerColor = Color(0xAA1E293B),
                                                onClick = { viewModel.setHeroIndex(state.activeHeroIndex - 1) }
                                            )
                                            TouchTvButton(
                                                text = "›",
                                                containerColor = Color(0xAA1E293B),
                                                onClick = { viewModel.setHeroIndex(state.activeHeroIndex + 1) }
                                            )
                                        }
                                    }
                                }
                            }
                            if (heroList.size > 1 && state.heroTrailerVideoId == null) {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(heroList.indices.toList()) { idx ->
                                        val isCurrent = idx == state.activeHeroIndex
                                        TouchTvButton(
                                            text = "${idx + 1}",
                                            containerColor = if (isCurrent) Color(0xFF2563EB) else Color(0xFF1E293B),
                                            onClick = { viewModel.setHeroIndex(idx) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Category", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(ContentTypeFilter.entries) { cat ->
                                val selected = state.selectedCategory == cat
                                TouchTvButton(
                                    text = cat.label,
                                    containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                    onClick = { viewModel.selectCategory(cat) }
                                )
                            }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Release Year", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(AppYearFilter.entries) { yr ->
                                val selected = state.selectedYear == yr
                                TouchTvButton(
                                    text = yr.label,
                                    containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                    onClick = { viewModel.selectYear(yr) }
                                )
                            }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Language (Original + Dubbed)", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(AppLanguage.entries) { lang ->
                                val selected = state.selectedLanguage == lang
                                TouchTvButton(
                                    text = lang.label,
                                    containerColor = if (selected) Color(0xFF2563EB) else Color(0xFF1E293B),
                                    onClick = { viewModel.selectLanguage(lang) }
                                )
                            }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("OTT Apps", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            state.selectedPlatform?.let { selected ->
                                TouchTvButton(
                                    text = "Open ${selected.displayName}",
                                    containerColor = platformAccent(selected),
                                    onClick = { AppLauncher.openPlatform(context, selected) }
                                )
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            item {
                                val isAll = state.selectedPlatform == null
                                TouchTvCard(
                                    onClick = { viewModel.selectPlatform(null) },
                                    selected = isAll,
                                    modifier = Modifier.width(105.dp).height(78.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize().background(Color(0xFF1E293B)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("All OTT", style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            items(OttPlatform.entries) { platform ->
                                val accent = platformAccent(platform)
                                val isSelected = state.selectedPlatform == platform
                                TouchTvCard(
                                    onClick = { viewModel.selectPlatform(platform) },
                                    selected = isSelected,
                                    modifier = Modifier.width(182.dp).height(78.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.85f), Color(0xFF1E293B))))
                                            .padding(horizontal = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(platformShortTag(platform), style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                        Column {
                                            Text(platform.displayName, style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text(platformSubtitle(platform), style = MaterialTheme.typography.labelSmall, color = Color(0xFFE2E8F0), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                val cat = state.selectedCategory
                if (state.watchlist.isNotEmpty()) {
                    item { ContentRow("My Watchlist (${state.currentUser?.name ?: "Guest"})", state.watchlist) { viewModel.openDetail(it) } }
                }
                if (state.recentViewed.isNotEmpty()) {
                    item { ContentRow("Recently Viewed", state.recentViewed) { viewModel.openDetail(it) } }
                }
                if (state.liveChannels.isNotEmpty()) {
                    item { ContentRow("TV Live Channels", state.liveChannels) { viewModel.openDetail(it) } }
                }
                if ((cat == ContentTypeFilter.ALL) && state.forYou.isNotEmpty()) {
                    item { ContentRow("My Interested Content", state.forYou) { viewModel.openDetail(it) } }
                }
                if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.MOVIES) && state.latestMovies.isNotEmpty()) {
                    item { ContentRow("Latest Movies", state.latestMovies) { viewModel.openDetail(it) } }
                }
                if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.WEB_SERIES) && state.webSeries.isNotEmpty()) {
                    item { ContentRow("Top Web Series", state.webSeries) { viewModel.openDetail(it) } }
                }
                if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.SHORT_SERIES) && state.shortSeries.isNotEmpty()) {
                    item { ContentRow("Short Series & Mini Shows", state.shortSeries) { viewModel.openDetail(it) } }
                }
                if ((cat == ContentTypeFilter.ALL || cat == ContentTypeFilter.MOVIES) && state.mostRated.isNotEmpty()) {
                    item { ContentRow("Most Rated", state.mostRated) { viewModel.openDetail(it) } }
                }
                if (cat == ContentTypeFilter.ALL && state.youtubeTrending.isNotEmpty()) {
                    item { ContentRow("Trending on YouTube", state.youtubeTrending) { viewModel.openDetail(it) } }
                }
            }
        }

        if (state.showMenu) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x88000000))
                    .clickable { viewModel.toggleMenu(false) },
                contentAlignment = Alignment.TopEnd
            ) {
                Column(
                    modifier = Modifier
                        .padding(top = 64.dp, end = 20.dp)
                        .width(220.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF161D2E))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TouchTvButton("↻ Refresh Catalog", Color(0xFF1E293B), {
                        viewModel.toggleMenu(false)
                        viewModel.refresh()
                    }, Modifier.fillMaxWidth())
                    TouchTvButton("⚙ Interactive Settings", Color(0xFF1E293B), { viewModel.toggleSettings(true) }, Modifier.fillMaxWidth())
                    TouchTvButton("★ Edit My Interests", Color(0xFF1E293B), { viewModel.toggleInterestPicker(true) }, Modifier.fillMaxWidth())
                    TouchTvButton("Close Menu", Color(0xFF334155), { viewModel.toggleMenu(false) }, Modifier.fillMaxWidth())
                }
            }
        }

        if (state.showSettings) {
            var emailInput by remember { mutableStateOf(state.currentUser?.email ?: "") }
            var nameInput by remember { mutableStateOf(state.currentUser?.name ?: "") }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000))
                    .clickable { viewModel.toggleSettings(false) },
                contentAlignment = Alignment.Center
            ) {
                LazyColumn(
                    modifier = Modifier
                        .width(480.dp)
                        .heightIn(max = 560.dp)
                        .padding(20.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF161D2E))
                        .clickable { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("Interactive Settings & About", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold) }
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0F172A))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Account & Watchlist Sync (About)", style = MaterialTheme.typography.titleSmall, color = Color(0xFF38BDF8))
                            val user = state.currentUser
                            if (user != null) {
                                Text("Signed in as: ${user.name} (${user.email})", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                TouchTvButton("Sign Out", Color(0xFF7F1D1D), { viewModel.logoutUser() })
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF1E293B)).padding(10.dp)
                                ) {
                                    if (emailInput.isEmpty()) Text("Google Email (e.g. name@gmail.com)", color = Color(0xFF94A3B8), style = MaterialTheme.typography.bodySmall)
                                    BasicTextField(
                                        value = emailInput,
                                        onValueChange = { emailInput = it },
                                        singleLine = true,
                                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                        cursorBrush = SolidColor(Color(0xFF38BDF8)),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                Box(
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF1E293B)).padding(10.dp)
                                ) {
                                    if (nameInput.isEmpty()) Text("Display Name", color = Color(0xFF94A3B8), style = MaterialTheme.typography.bodySmall)
                                    BasicTextField(
                                        value = nameInput,
                                        onValueChange = { nameInput = it },
                                        singleLine = true,
                                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                        cursorBrush = SolidColor(Color(0xFF38BDF8)),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                TouchTvButton("Sign In / Save Profile", Color(0xFF2563EB), {
                                    viewModel.loginUser(emailInput, nameInput)
                                })
                            }
                            Text("StreamHub TV v3.0 • Each profile saves its own Watchlist & Recent Views.", color = Color(0xFF94A3B8), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    item {
                    Text("App Theme", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            val active = state.themeMode == mode
                            TouchTvButton(
                                text = if (active) "✓ ${mode.label}" else mode.label,
                                containerColor = if (active) Color(0xFF2563EB) else Color(0xFF1E293B),
                                onClick = { viewModel.setThemeMode(mode) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    TouchTvButton(
                        text = if (state.autoSlideHero) "Top 10 Auto-Slide: ON" else "Top 10 Auto-Slide: OFF",
                        containerColor = if (state.autoSlideHero) Color(0xFF0F766E) else Color(0xFF334155),
                        onClick = { viewModel.setAutoSlideHero(!state.autoSlideHero) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("My Subscribed / Logged-in OTT Apps", style = MaterialTheme.typography.titleSmall, color = Color(0xFF94A3B8))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(OttPlatform.entries) { plat ->
                            val active = plat in state.enabledPlatforms
                            TouchTvButton(
                                text = if (active) "✓ ${plat.displayName}" else plat.displayName,
                                containerColor = if (active) Color(0xFF059669) else Color(0xFF1E293B),
                                onClick = { viewModel.togglePlatformEnabled(plat) }
                            )
                        }
                    }
                    TouchTvButton(
                        text = "Reset Saved Interests",
                        containerColor = Color(0xFF7F1D1D),
                        onClick = { viewModel.resetGenres() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TouchTvButton(
                        text = "Close Settings",
                        containerColor = Color(0xFF334155),
                        onClick = { viewModel.toggleSettings(false) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    }
                }
            }
        }

        if (state.showExitDialog) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000))
                    .clickable { viewModel.setExitDialog(false) },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .width(380.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF161D2E))
                        .clickable { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Do you want to exit?", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Are you sure you want to close StreamHub TV?", style = MaterialTheme.typography.bodySmall, color = Color(0xFF94A3B8))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TouchTvButton("Yes, Exit", Color(0xFFDC2626), { activity?.finish() })
                        TouchTvButton("No, Stay", Color(0xFF2563EB), { viewModel.setExitDialog(false) })
                    }
                }
            }
        }

        if (state.showSearch) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xE6060911))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            if (state.searchQuery.isEmpty()) {
                                Text("Search movies, web series, YouTube...", color = Color(0xFF94A3B8), style = MaterialTheme.typography.bodyMedium)
                            }
                            BasicTextField(
                                value = state.searchQuery,
                                onValueChange = { viewModel.updateSearchQuery(it) },
                                singleLine = true,
                                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                                cursorBrush = SolidColor(Color(0xFF38BDF8)),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        TouchTvButton("Search", Color(0xFF2563EB), { viewModel.executeSearch() })
                        TouchTvButton("Close", Color(0xFF334155), { viewModel.toggleSearch(false) })
                    }

                    if (state.isSearching) {
                        Text("Searching...", color = Color(0xFF60A5FA))
                    } else if (state.searchResults.isNotEmpty()) {
                        ContentRow("Search Results (${state.searchResults.size})", state.searchResults) {
                            viewModel.toggleSearch(false)
                            viewModel.openDetail(it)
                        }
                    } else if (state.searchQuery.isNotBlank()) {
                        Text("Tap Search to find titles across OTT & YouTube.", color = Color(0xFF94A3B8))
                    }
                }
            }
        }

        state.loginPromptMessage?.let { msg ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
                    .clickable { viewModel.showLoginPrompt(null) },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .width(420.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF161D2E))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(msg, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TouchTvButton("Open Settings", Color(0xFF2563EB), {
                            viewModel.showLoginPrompt(null)
                            viewModel.toggleSettings(true)
                        })
                        TouchTvButton("Close", Color(0xFF334155), { viewModel.showLoginPrompt(null) })
                    }
                }
            }
        }


    }
}

@Composable
private fun DetailScreen(
    item: MediaItem,
    cast: List<CastMember>,
    similar: List<MediaItem>,
    isLoadingDetails: Boolean,
    isLoadingTrailer: Boolean,
    hasFreeStream: Boolean,
    inWatchlist: Boolean,
    onToggleWatchlist: () -> Unit,
    inlineTrailerId: String?,
    inlineMp4Url: String?,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onCloseInlinePlayer: () -> Unit,
    onBack: () -> Unit,
    onHome: () -> Unit,
    onWatch: () -> Unit,
    onWatchFree: () -> Unit,
    onPlayTrailer: () -> Unit,
    onSelectSimilar: (MediaItem) -> Unit
) {
    val accent = platformAccent(item.platform)
    val ratingText = if (item.rating > 0) String.format("%.1f", item.rating) else "Trending"
    val isPlayingInline = inlineTrailerId != null || inlineMp4Url != null

    if (isFullscreen && isPlayingInline) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (inlineMp4Url != null) {
                InlineExoPlayerView(streamUrl = inlineMp4Url, modifier = Modifier.fillMaxSize())
            } else if (inlineTrailerId != null) {
                EmbeddedYouTubePlayer(videoId = inlineTrailerId, modifier = Modifier.fillMaxSize())
            }
            Row(
                modifier = Modifier.align(Alignment.TopEnd).padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TouchTvButton("⛶ Exit Fullscreen", Color(0xCC1E293B), onToggleFullscreen)
                TouchTvButton("✕ Close", Color(0xCCDC2626), onCloseInlinePlayer)
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TouchTvButton("← Back", Color(0xFF1E293B), onBack)
                TouchTvButton("🏠 Home", Color(0xFF2563EB), onHome)
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF161D2E))
            ) {
                if (inlineMp4Url != null) {
                    InlineExoPlayerView(streamUrl = inlineMp4Url, modifier = Modifier.fillMaxSize())
                    Row(
                        modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TouchTvButton("⛶ Full", Color(0xCC1E293B), onToggleFullscreen)
                        TouchTvButton("✕ Close", Color(0xCCDC2626), onCloseInlinePlayer)
                    }
                } else if (inlineTrailerId != null) {
                    EmbeddedYouTubePlayer(videoId = inlineTrailerId, modifier = Modifier.fillMaxSize())
                    Row(
                        modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TouchTvButton("⛶ Full", Color(0xCC1E293B), onToggleFullscreen)
                        TouchTvButton("✕ Close", Color(0xCCDC2626), onCloseInlinePlayer)
                    }
                } else {
                    if (item.imageUrl.isNotBlank()) {
                        AsyncImage(
                            model = item.imageUrl,
                            contentDescription = item.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0x44060911), Color(0xEE060911))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${item.contentTypeLabel.uppercase()} • ${item.platform.displayName.uppercase()} • ★ $ratingText • ${item.releaseDate}",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { TouchTvButton("Watch on ${item.platform.displayName}", accent, onWatch) }
                    if (hasFreeStream) {
                        item {
                            TouchTvButton(
                                text = "▶ Watch Free",
                                containerColor = Color(0xFF059669),
                                onClick = onWatchFree
                            )
                        }
                    }
                    item {
                        TouchTvButton(
                            text = if (inWatchlist) "✓ In Watchlist" else "+ Watchlist",
                            containerColor = if (inWatchlist) Color(0xFF0F766E) else Color(0xFF1E293B),
                            onClick = onToggleWatchlist
                        )
                    }
                    item {
                        TouchTvButton(
                            text = if (isLoadingTrailer) "Loading..." else "▶ Trailer",
                            containerColor = Color(0xFFDC2626),
                            onClick = onPlayTrailer
                        )
                    }
                }
                Text(
                    text = item.overview.ifBlank { "No description available. Tap Watch or Trailer above." },
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFD1D5DB)
                )
            }
        }

        if (isLoadingDetails) {
            item {
                Text("Loading star cast & similar titles...", color = Color(0xFF60A5FA))
            }
        }

        if (cast.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Star Cast", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(cast, key = { it.id }) { actor ->
                            Column(
                                modifier = Modifier
                                    .width(108.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF161D2E))
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (actor.photoUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = actor.photoUrl,
                                        contentDescription = actor.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(68.dp).clip(CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier.size(68.dp).clip(CircleShape).background(Color(0xFF1E293B)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(actor.name.take(1), color = Color.White, style = MaterialTheme.typography.titleLarge)
                                    }
                                }
                                Text(
                                    text = actor.name,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (actor.character.isNotBlank()) {
                                    Text(
                                        text = actor.character,
                                        color = Color(0xFF94A3B8),
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (similar.isNotEmpty()) {
            item {
                ContentRow("Similar ${item.contentTypeLabel}s", similar, onSelectSimilar)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun EmbeddedYouTubePlayer(
    videoId: String,
    modifier: Modifier = Modifier
) {
    val embedHtml = """
        <!DOCTYPE html>
        <html>
        <head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
        <body style="margin:0;padding:0;background:#000;overflow:hidden;">
        <iframe
            style="position:fixed;top:0;left:0;width:100%;height:100%;border:0;"
            src="https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3&controls=1"
            allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowfullscreen>
        </iframe>
        </body>
        </html>
    """.trimIndent()

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.domStorageEnabled = true
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()
                loadDataWithBaseURL("https://www.youtube-nocookie.com", embedHtml, "text/html", "utf-8", null)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL("https://www.youtube-nocookie.com", embedHtml, "text/html", "utf-8", null)
        },
        modifier = modifier
    )
}

@Composable
private fun SmallScreenTrailerPlayer(
    videoId: String,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 560.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F172A))
                .clickable { }
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("▶ Trailer Player", color = Color.White, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                TouchTvButton("✕ Close", Color(0xFFDC2626), onClose)
            }
            EmbeddedYouTubePlayer(
                videoId = videoId,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
        }
    }
}

@Composable
private fun ContentRow(
    title: String,
    items: List<MediaItem>,
    onSelect: (MediaItem) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Color.White)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items, key = { it.id }) { item ->
                val accent = platformAccent(item.platform)
                val cardRating = String.format("%.1f", item.rating)
                TouchTvCard(
                    onClick = { onSelect(item) },
                    modifier = Modifier.width(172.dp).height(250.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF161D2E))) {
                        Box(modifier = Modifier.fillMaxWidth().height(172.dp)) {
                            if (item.imageUrl.isNotBlank()) {
                                AsyncImage(
                                    model = item.imageUrl,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.8f), Color(0xFF1E293B)))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(platformShortTag(item.platform), style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (item.rating > 0) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xCC0F172A))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("★ $cardRating", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFACC15))
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(accent)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(item.platform.displayName, style = MaterialTheme.typography.labelSmall, color = Color.White)
                            }
                        }

                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun InbuiltExoPlayerOverlay(
    streamUrl: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember(streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }
    var audioTracks by remember { mutableStateOf<List<Pair<String, androidx.media3.common.TrackGroup>>>(emptyList()) }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val found = mutableListOf<Pair<String, androidx.media3.common.TrackGroup>>()
                for (group in tracks.groups) {
                    if (group.type == C.TRACK_TYPE_AUDIO && group.length > 0) {
                        val lang = group.getTrackFormat(0).language ?: "Default"
                        found.add(lang.uppercase() to group.mediaTrackGroup)
                    }
                }
                audioTracks = found
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F172A))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("▶ Inbuilt Video Player", color = Color.White, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                TouchTvButton("✕ Close", Color(0xFFDC2626), onClose)
            }
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
            if (audioTracks.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text("Audio:", color = Color(0xFF94A3B8), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                    }
                    items(audioTracks) { (label, group) ->
                        TouchTvButton(
                            text = label,
                            containerColor = Color(0xFF2563EB),
                            onClick = {
                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                    .buildUpon()
                                    .setOverrideForType(TrackSelectionOverride(group, 0))
                                    .build()
                            }
                        )
                    }
                }
            }
        }
    }
}


@Composable
private fun InlineExoPlayerView(
    streamUrl: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val exoPlayer = remember(streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(streamUrl))
            prepare()
            playWhenReady = true
        }
    }
    var audioTracks by remember { mutableStateOf<List<Pair<String, androidx.media3.common.TrackGroup>>>(emptyList()) }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val found = mutableListOf<Pair<String, androidx.media3.common.TrackGroup>>()
                for (group in tracks.groups) {
                    if (group.type == C.TRACK_TYPE_AUDIO && group.length > 0) {
                        val lang = group.getTrackFormat(0).language ?: "Default"
                        found.add(lang.uppercase() to group.mediaTrackGroup)
                    }
                }
                audioTracks = found
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    Box(modifier = modifier.background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        if (audioTracks.size > 1) {
            LazyRow(
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(audioTracks) { (label, group) ->
                    TouchTvButton(
                        text = label,
                        containerColor = Color(0xCC2563EB),
                        onClick = {
                            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                .buildUpon()
                                .setOverrideForType(TrackSelectionOverride(group, 0))
                                .build()
                        }
                    )
                }
            }
        }
    }
}
