package com.streamhub.tv.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class TmdbResponse(val results: List<TmdbMovieDto> = emptyList())

data class TmdbMovieDto(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    val overview: String? = null,
    val poster_path: String? = null,
    val backdrop_path: String? = null,
    val vote_average: Double = 0.0,
    val release_date: String? = null,
    val first_air_date: String? = null,
    val genre_ids: List<Int>? = null,
    val media_type: String? = null
)

data class TmdbCreditsResponse(val cast: List<TmdbCastDto> = emptyList())
data class TmdbCastDto(
    val id: Int,
    val name: String = "",
    val character: String? = null,
    val profile_path: String? = null
)

data class TmdbVideosResponse(val results: List<TmdbVideoDto> = emptyList())
data class TmdbVideoDto(
    val key: String = "",
    val site: String = "",
    val type: String = ""
)

interface TmdbApi {
    @GET("3/discover/movie")
    suspend fun discoverMovies(
        @Query("api_key") apiKey: String,
        @Query("watch_region") region: String = "IN",
        @Query("with_watch_providers") providers: String = "119|122|2336|232|237",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("vote_count.gte") minVotes: Int = 0,
        @Query("language") language: String = "en-IN",
        @Query("with_original_language") originalLanguage: String? = null,
        @Query("primary_release_year") year: Int? = null
    ): TmdbResponse

    @GET("3/discover/tv")
    suspend fun discoverTv(
        @Query("api_key") apiKey: String,
        @Query("watch_region") region: String = "IN",
        @Query("with_watch_providers") providers: String = "119|122|2336|232|237",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("vote_count.gte") minVotes: Int = 0,
        @Query("language") language: String = "en-IN",
        @Query("with_original_language") originalLanguage: String? = null,
        @Query("with_runtime.lte") maxRuntime: Int? = null,
        @Query("first_air_date_year") year: Int? = null
    ): TmdbResponse

    @GET("3/search/multi")
    suspend fun searchMulti(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("language") language: String = "en-IN"
    ): TmdbResponse

    @GET("3/movie/{id}/credits")
    suspend fun getMovieCredits(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String
    ): TmdbCreditsResponse

    @GET("3/tv/{id}/credits")
    suspend fun getTvCredits(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String
    ): TmdbCreditsResponse

    @GET("3/movie/{id}/similar")
    suspend fun getMovieSimilar(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "en-IN"
    ): TmdbResponse

    @GET("3/tv/{id}/similar")
    suspend fun getTvSimilar(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "en-IN"
    ): TmdbResponse

    @GET("3/movie/{id}/videos")
    suspend fun getMovieVideos(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String
    ): TmdbVideosResponse

    @GET("3/tv/{id}/videos")
    suspend fun getTvVideos(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String
    ): TmdbVideosResponse
}

data class YouTubeResponse(val items: List<YouTubeVideoDto> = emptyList())
data class YouTubeVideoDto(val id: String, val snippet: YouTubeSnippet)

data class YouTubeSearchResponse(val items: List<YouTubeSearchDto> = emptyList())
data class YouTubeSearchDto(val id: YouTubeSearchId, val snippet: YouTubeSnippet)
data class YouTubeSearchId(val videoId: String? = null)

data class YouTubeSnippet(
    val title: String,
    val description: String,
    val publishedAt: String,
    val thumbnails: YouTubeThumbnails
)
data class YouTubeThumbnails(val high: YouTubeThumb? = null, val medium: YouTubeThumb? = null)
data class YouTubeThumb(val url: String)

interface YouTubeApi {
    @GET("youtube/v3/videos")
    suspend fun getTrending(
        @Query("part") part: String = "snippet",
        @Query("chart") chart: String = "mostPopular",
        @Query("regionCode") regionCode: String = "IN",
        @Query("maxResults") maxResults: Int = 15,
        @Query("key") apiKey: String
    ): YouTubeResponse

    @GET("youtube/v3/search")
    suspend fun searchByLanguage(
        @Query("part") part: String = "snippet",
        @Query("type") type: String = "video",
        @Query("order") order: String = "viewCount",
        @Query("regionCode") regionCode: String = "IN",
        @Query("relevanceLanguage") relevanceLanguage: String,
        @Query("q") query: String,
        @Query("videoEmbeddable") embeddable: String = "true",
        @Query("videoDuration") videoDuration: String? = null,
        @Query("eventType") eventType: String? = null,
        @Query("maxResults") maxResults: Int = 15,
        @Query("key") apiKey: String
    ): YouTubeSearchResponse
}

data class ArchiveSearchResponse(val response: ArchiveResponseBody? = null)
data class ArchiveResponseBody(val docs: List<ArchiveDoc> = emptyList())
data class ArchiveDoc(val identifier: String = "", val title: String? = null)

data class ArchiveMetadataResponse(val files: List<ArchiveFile> = emptyList())
data class ArchiveFile(val name: String = "", val format: String? = null)

interface ArchiveApi {
    @GET("advancedsearch.php")
    suspend fun searchMovies(
        @Query("q") query: String,
        @Query("fl[]") field: String = "identifier",
        @Query("rows") rows: Int = 3,
        @Query("output") output: String = "json"
    ): ArchiveSearchResponse

    @GET("metadata/{id}")
    suspend fun getMetadata(@Path("id") identifier: String): ArchiveMetadataResponse
}

object DoHDns : okhttp3.Dns {
    private val cache = mutableMapOf<String, List<java.net.InetAddress>>()
    private val ipRegex = Regex("\"data\":\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"")

    override fun lookup(hostname: String): List<java.net.InetAddress> {
        if (hostname.contains("themoviedb.org") || hostname.contains("tmdb.org")) {
            cache[hostname]?.let { return it }
            try {
                val conn = java.net.URL("https://8.8.8.8/resolve?name=$hostname&type=A")
                    .openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                conn.setRequestProperty("Accept", "application/dns-json")
                val body = conn.inputStream.bufferedReader().readText()
                val ips = ipRegex.findAll(body)
                    .mapNotNull { m ->
                        try { java.net.InetAddress.getByName(m.groupValues[1]) } catch (_: Exception) { null }
                    }.toList()
                if (ips.isNotEmpty()) {
                    cache[hostname] = ips
                    return ips
                }
            } catch (_: Exception) { }
        }
        return okhttp3.Dns.SYSTEM.lookup(hostname)
    }
}

object NetworkModule {
    val okHttpClient: okhttp3.OkHttpClient by lazy {
        okhttp3.OkHttpClient.Builder()
            .dns(DoHDns)
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    val tmdb: TmdbApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.themoviedb.org/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TmdbApi::class.java)
    }

    val youtube: YouTubeApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://www.googleapis.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(YouTubeApi::class.java)
    }

    val archive: ArchiveApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://archive.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ArchiveApi::class.java)
    }
}
