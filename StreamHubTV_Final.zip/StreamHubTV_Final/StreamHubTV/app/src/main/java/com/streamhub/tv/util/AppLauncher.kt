package com.streamhub.tv.util

import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.streamhub.tv.model.OttPlatform

object AppLauncher {
    private fun platformSearchUrl(platform: OttPlatform, query: String): String? {
        val q = Uri.encode(query)
        return when (platform) {
            OttPlatform.JIO_HOTSTAR -> "https://www.hotstar.com/in/explore?search_query=$q"
            OttPlatform.PRIME_VIDEO -> "https://www.primevideo.com/search/ref=atv_nb_sr?phrase=$q"
            OttPlatform.ZEE5 -> "https://www.zee5.com/search?q=$q"
            OttPlatform.SONY_LIV -> "https://www.sonyliv.com/search/$q"
            OttPlatform.YOUTUBE -> "https://www.youtube.com/results?search_query=$q"
            OttPlatform.JIO_TV -> null
        }
    }

    fun openPlatform(
        context: Context,
        platform: OttPlatform,
        url: String? = null,
        titleQuery: String? = null
    ) {
        val pm = context.packageManager

        if (!titleQuery.isNullOrBlank() && platform != OttPlatform.YOUTUBE && platform != OttPlatform.JIO_TV) {
            try {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Movie Title", titleQuery))
            } catch (_: Exception) { }

            val searchUrl = platformSearchUrl(platform, titleQuery)
            if (searchUrl != null) {
                for (pkg in listOf(platform.packageName, platform.mobilePackageName)) {
                    try {
                        val deepIntent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                            setPackage(pkg)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        if (deepIntent.resolveActivity(pm) != null) {
                            context.startActivity(deepIntent)
                            return
                        }
                    } catch (_: Exception) { }
                }
            }

            for (pkg in listOf(platform.packageName, platform.mobilePackageName)) {
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(pkg)
                        putExtra(SearchManager.QUERY, titleQuery)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (searchIntent.resolveActivity(pm) != null) {
                        context.startActivity(searchIntent)
                        return
                    }
                } catch (_: Exception) { }
            }
        }

        if (!url.isNullOrBlank() && platform == OttPlatform.YOUTUBE) {
            for (pkg in listOf(platform.packageName, platform.mobilePackageName)) {
                try {
                    val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(ytIntent)
                    return
                } catch (_: Exception) { }
            }
        }

        val launchIntent = pm.getLeanbackLaunchIntentForPackage(platform.packageName)
            ?: pm.getLaunchIntentForPackage(platform.mobilePackageName)
            ?: pm.getLaunchIntentForPackage(platform.packageName)

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (!titleQuery.isNullOrBlank()) {
                Toast.makeText(context, "Opening ${platform.displayName} (\"$titleQuery\" copied)", Toast.LENGTH_SHORT).show()
            }
            context.startActivity(launchIntent)
            return
        }

        try {
            val targetUrl = if (!titleQuery.isNullOrBlank()) {
                platformSearchUrl(platform, titleQuery) ?: platform.fallbackWebUrl
            } else {
                url?.takeIf { it.isNotBlank() } ?: platform.fallbackWebUrl
            }
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        } catch (_: Exception) {
            Toast.makeText(context, "${platform.displayName} is not installed.", Toast.LENGTH_SHORT).show()
        }
    }

    fun openYouTubeTrailer(context: Context, title: String) {
        val queryUrl = "https://www.youtube.com/results?search_query=${Uri.encode("$title official trailer")}"
        for (pkg in listOf(OttPlatform.YOUTUBE.packageName, OttPlatform.YOUTUBE.mobilePackageName)) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(queryUrl)).apply {
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) { }
        }
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(queryUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) { }
    }
}
